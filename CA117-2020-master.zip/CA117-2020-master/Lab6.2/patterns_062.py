date = r"\d{1,2}[/-]\d{1,2}[/-]\d{2}"
phone = r"01[ -]\d{7}"
email = r"\w[\w\.]+@.[\w\.]+\w"
ldate = r"\d{2} [A-Za-z]{3} \d{2}"
