swap_keys_values = lambda d: dict(zip(d.values(), d.keys()))
